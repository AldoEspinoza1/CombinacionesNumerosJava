/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package numeros_recursivos;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Aldo
 */
public class Numeros_recursivos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner entrada_sc = new Scanner(System.in);
        System.out.print("Dame un numero : ");
        int n = entrada_sc.nextInt();
        ArrayList<Integer> numeros = new ArrayList<>();
        combinacionesSuma(n,numeros,0);
    }
    
    public static void combinacionesSuma(int numero,ArrayList<Integer> numeros,int suma){
        if(suma == numero){
            System.out.println(numeros);
            
        }
        else {
                for (int i = 1; i <=numero; i++) {
            suma+=i;
            if (suma<=numero) {
                numeros.add(i);
                combinacionesSuma(numero,numeros,suma);
                numeros.remove(numeros.indexOf(i));
            }
             suma-=i;
        }
    }
        
        

        
        
        
        
    }
}
